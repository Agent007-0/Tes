# LobbySystem
This LobbySystem is for beginners. I don't have to say more about that here. You can find all information in the settings.yml.

# Config
```yaml
# Use ID-Meta-Count-Slot-Name-Command
# Example:
# items:
#   - 345-0-1-4-§bTeleport-help
items:
  - 345-0-1-4-§bTeleport-help

# Gamemode on join
gamemode: 2

# Change the join and leave message.
# To disable the messages, leave the fields as they were at the beginning.
# Like: join: ""
messages:
  join: ""
  quit: ""

# Change the Events
# Use true or false
events:
  place: false
  break: false
  hunger: false
  inv-move: false
  drop: false
  pick: false
```